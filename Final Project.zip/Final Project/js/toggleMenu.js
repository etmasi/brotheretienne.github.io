function toggleMenu() {
    document.getElementById("lastUpdate").classList.toggle("hide");
}