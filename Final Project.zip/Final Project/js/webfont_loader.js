WebFont.load({
    google: {
      families: [
         'Bree+Serif',
         'Merriweather+Sans'
      ]
    }
  });