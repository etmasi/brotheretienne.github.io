function toggleMenu() {
  document.querySelector("#primaryNav").classList.toggle("hide");
}
